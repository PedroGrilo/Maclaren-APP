package com.gabrielmiguelpedro.maclarenapp.Exceptions;

public class EmailErrorException extends Exception {
    public EmailErrorException(String exception) {
        super(exception);
    }
}
