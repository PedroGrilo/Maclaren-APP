package com.gabrielmiguelpedro.maclarenapp.Exceptions;

public class EmptyFieldException extends Exception {
    public EmptyFieldException(String exception) {
        super(exception);
    }
}
