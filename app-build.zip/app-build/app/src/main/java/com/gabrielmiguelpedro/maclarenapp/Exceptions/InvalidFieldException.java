package com.gabrielmiguelpedro.maclarenapp.Exceptions;

public class InvalidFieldException extends Exception {
    public InvalidFieldException(String exception) {
        super(exception);
    }
}
